
The Protel99 (Now known as ALtium) decals were provided by Martin Hollenweger of 3xS Srl, Italy.


TC2030: Directory containing a protel Project for the TC2030-MCP and the TC2030_MCP-NL
		 TC2030.pfp is the PCB library
		 TC2030.pcb is a example PCB
		 TC2030.ddb is the protel 99SE database file

CAN for TC2030 contains the Gerber and NC-Drill files of the example PCB



WE RECOMMEND CHANGING THE ALIGNMENT PIN HOLES TO BE AT LEAST 0.0374" - see latest drawing at www.Tag-Connect.com
